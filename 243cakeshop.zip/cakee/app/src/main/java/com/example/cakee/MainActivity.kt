package com.example.cakee

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var rootLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rootLayout = findViewById(R.id.rootLayout)

        showLoginScreen()
    }

    private fun showLoginScreen() {
        rootLayout.removeAllViews()

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 26f
            setPadding(0, 0, 0, 50)
        }

        val username = EditText(this).apply {
            hint = getString(R.string.username_hint)
        }

        val password = EditText(this).apply {
            hint = getString(R.string.password_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val loginBtn = Button(this).apply {
            text = getString(R.string.login)
        }

        loginBtn.setOnClickListener {
            if (username.text.toString() == "user" && password.text.toString() == "pass") {
                showCakeMenu()
            } else {
                Toast.makeText(this, getString(R.string.invalid_login), Toast.LENGTH_SHORT).show()
            }
        }

        rootLayout.addView(title)
        rootLayout.addView(username)
        rootLayout.addView(password)
        rootLayout.addView(loginBtn)
    }

    private fun showCakeMenu() {
        rootLayout.removeAllViews()

        val cakeList = listOf(
            CakeItem("chocolate_cake", R.string.chocolate_label, "Chocolate Cake", 150),
            CakeItem("vanilla_cake", R.string.vanilla_label, "Vanilla Cake", 120),
            CakeItem("red_velvet", R.string.red_velvet_label, "Red Velvet Cake", 200),
            CakeItem("black_forest", R.string.black_forest_label, "Black Forest Cake", 180),
            CakeItem("strawberry_cake", R.string.strawberry_label, "Strawberry Cake", 170),
            CakeItem("butterscotch_cake", R.string.butterscotch_label, "Butterscotch Cake", 160)
        )

        val quantityMap = mutableMapOf<String, NumberPicker>()

        for (cake in cakeList) {
            val image = ImageView(this).apply {
                setImageResource(resources.getIdentifier(cake.imageName, "drawable", packageName))
                layoutParams = LinearLayout.LayoutParams(400, 400)
            }

            val label = TextView(this).apply {
                text = getString(cake.labelId)
                textSize = 18f
            }

            val qty = NumberPicker(this).apply {
                minValue = 0
                maxValue = 10
            }

            rootLayout.addView(image)
            rootLayout.addView(label)
            rootLayout.addView(qty)

            quantityMap[cake.name] = qty
        }

        val addToCartBtn = Button(this).apply {
            text = getString(R.string.add_to_cart)
        }

        addToCartBtn.setOnClickListener {
            var total = 0
            val summaryList = mutableListOf<String>()

            for (cake in cakeList) {
                val qty = quantityMap[cake.name]?.value ?: 0
                if (qty > 0) {
                    val line = "$qty x ${cake.displayName} = ₹${qty * cake.price}"
                    summaryList.add(line)
                    total += qty * cake.price
                }
            }

            showBillScreen(summaryList, total)
        }

        rootLayout.addView(addToCartBtn)
    }

    private fun showBillScreen(summaryList: List<String>, total: Int) {
        rootLayout.removeAllViews()

        val summaryTitle = TextView(this).apply {
            text = "🧾 Order Summary:"
            textSize = 20f
            setPadding(0, 20, 0, 10)
        }

        rootLayout.addView(summaryTitle)

        for (line in summaryList) {
            val itemText = TextView(this).apply {
                text = line
                textSize = 16f
            }
            rootLayout.addView(itemText)
        }

        val billText = TextView(this).apply {
            text = getString(R.string.total_bill, total)
            textSize = 22f
            setPadding(0, 30, 0, 20)
        }

        val placeOrderBtn = Button(this).apply {
            text = getString(R.string.place_order)
        }

        placeOrderBtn.setOnClickListener {
            Toast.makeText(this, getString(R.string.order_placed), Toast.LENGTH_LONG).show()
            showLoginScreen()
        }

        rootLayout.addView(billText)
        rootLayout.addView(placeOrderBtn)
    }

    data class CakeItem(
        val imageName: String,
        val labelId: Int,
        val name: String,
        val price: Int,
        val displayName: String = name
    )
}
